# PNJ Manhwa — Groupes & Scène

Groupes de PNJ (acteurs Foundry) et barre de portraits affichée à l'écran des joueurs, dans l'esprit de ConversationHUD.

- **Groupes** : créés dans la fenêtre (bouton *PNJ Manhwa* dans les contrôles de jetons, MJ seulement) ; un acteur peut être dans plusieurs groupes ; ordre manuel par glisser, tri par nom ou par étiquette, filtre, recherche.
- **Ajout** : glisser des acteurs depuis le répertoire vers la liste, ou « Ajouter des PNJ » (liste filtrable).
- **Étiquettes** : libres (« Groupe 1 », « Classe S »…), avec couleur, plusieurs par PNJ ; visibles des joueurs seulement si l'option est cochée.
- **Scène** : « Scène visible / masquée », taille (60–320 px), position (bas, haut, gauche, droite), cadre (rond, arrondi, hexagone, carré), fond, titre facultatif, thème.
- **Orateurs** : plusieurs possibles ; bouton bulle dans la liste, ou clic MJ sur un portrait de la scène. Son doux facultatif (réglage).
- **Nom caché par défaut** : les joueurs voient `???` tant que le nom n'est pas révélé (œil) ; la révélation est enregistrée définitivement (re-cachable). Alias et image de remplacement par PNJ. Portrait masquable (silhouette).
- **Thèmes** : ORV néon (défaut), Eos médiéval, Clockwork cuivre, Nova cyber, Inertia sénat, Sobre.
- Données dans les réglages du monde (conservées aux mises à jour). Rien au clic des joueurs.
