/* PNJ Manhwa — Groupes & Scène · réglages, données, hooks */
import { Stage } from "./stage.js";
import { Manager } from "./manager.js";

export const MOD = "pnj-manhwa";
export const THEMES = {
  orv: "ORV — Néon (Système)",
  eos: "Eos — Médiéval (parchemin & or)",
  clockwork: "Clockwork — Cuivre & rouages",
  nova: "Nova — Cyber magenta",
  inertia: "Inertia — Sénat (velours & or)",
  sobre: "Sobre — Noir minimal"
};
export const POSITIONS = { bottom: "Bas", top: "Haut", left: "Gauche", right: "Droite" };
export const FRAMES = { round: "Rond", rounded: "Carré arrondi", hex: "Hexagone", square: "Carré" };
export const UNKNOWN = "???";

const DEFAULT_DATA = { v: 1, tags: [], groups: [], npcs: {} };
const DEFAULT_SCENE = { active: false, shown: [], speakers: [], size: 150, position: "bottom", frame: "rounded", bg: true, showTags: false, theme: "orv", title: "" };

export const uid = () => foundry.utils.randomID(10);
export const esc = s => foundry.utils.escapeHTML(String(s ?? ""));

/* ───────── accès aux données ───────── */
export function getData() { return foundry.utils.mergeObject(foundry.utils.deepClone(DEFAULT_DATA), game.settings.get(MOD, "data") || {}, { inplace: false }); }
export async function setData(d) { if (!game.user.isGM) return; await game.settings.set(MOD, "data", d); }
export function getScene() { return foundry.utils.mergeObject(foundry.utils.deepClone(DEFAULT_SCENE), game.settings.get(MOD, "scene") || {}, { inplace: false }); }
export async function setScene(patch) { if (!game.user.isGM) return; const s = getScene(); await game.settings.set(MOD, "scene", foundry.utils.mergeObject(s, patch, { inplace: false })); }
export async function updateData(fn) { const d = getData(); const r = await fn(d); if (r !== false) await setData(d); return d; }

/* fiche d'affichage d'un PNJ : acteur + surcharges + révélations */
export function npcView(actorId, data = getData(), scene = getScene()) {
  const a = game.actors.get(actorId); const o = data.npcs[actorId] || {};
  const revealed = !!o.revealed; const hidePortrait = !!o.hidePortrait;
  const realName = o.alias || a?.name || "PNJ supprimé";
  const img = o.img || a?.img || "icons/svg/mystery-man.svg";
  const tags = (o.tags || []).map(id => data.tags.find(t => t.id === id)).filter(Boolean);
  return { id: actorId, exists: !!a, actor: a, realName, img, revealed, hidePortrait, tags, tagIds: o.tags || [],
    name: (revealed || game.user.isGM) ? realName : UNKNOWN,
    shown: scene.shown.includes(actorId), speaker: scene.speakers.includes(actorId) };
}
export function ensureNpc(data, actorId) { data.npcs[actorId] ||= { alias: "", img: "", tags: [], revealed: false, hidePortrait: false }; return data.npcs[actorId]; }

/* tri des membres d'un groupe */
export function sortMembers(ids, mode, data) {
  const views = ids.map(id => npcView(id, data));
  if (mode === "name") views.sort((a, b) => a.realName.localeCompare(b.realName, "fr"));
  else if (mode === "tag") views.sort((a, b) => ((a.tags[0]?.name || "￿").localeCompare(b.tags[0]?.name || "￿", "fr")) || a.realName.localeCompare(b.realName, "fr"));
  return views;
}

/* ───────── réglages ───────── */
Hooks.once("init", () => {
  game.settings.register(MOD, "data", { scope: "world", config: false, type: Object, default: DEFAULT_DATA });
  game.settings.register(MOD, "scene", { scope: "world", config: false, type: Object, default: DEFAULT_SCENE });
  game.settings.register(MOD, "sound", { name: "Son à la prise de parole", hint: "Chemin d'un fichier audio (ogg/mp3/wav), joué doucement chez tout le monde quand un orateur change. Vide = aucun son.", scope: "world", config: true, type: String, default: "", filePicker: "audio" });
  game.settings.register(MOD, "soundVolume", { name: "Volume du son", scope: "world", config: true, type: Number, range: { min: 0, max: 1, step: 0.05 }, default: 0.25 });
  game.settings.register(MOD, "playerScale", { name: "Échelle de la scène (ce poste)", hint: "Multiplie la taille choisie par le MJ sur cet écran uniquement.", scope: "client", config: true, type: Number, range: { min: 0.5, max: 1.5, step: 0.05 }, default: 1, onChange: () => Stage.refresh() });
  game.settings.register(MOD, "gmClickSpeaker", { name: "MJ : un clic sur un portrait de la scène change l'orateur", scope: "client", config: true, type: Boolean, default: true });
});

Hooks.once("ready", () => {
  Stage.refresh();
  game.modules.get(MOD).api = { open: () => Manager.open(), refresh: () => Stage.refresh(), getData, getScene };
});

/* diffusion : les réglages de monde se propagent à tous les clients */
Hooks.on("updateSetting", (setting) => {
  if (setting.key === `${MOD}.scene` || setting.key === `${MOD}.data`) { Stage.refresh(); Manager.instance?.render(); }
});
Hooks.on("updateActor", (a, changes) => { if ("name" in changes || "img" in changes) { Stage.refresh(); Manager.instance?.render(); } });
Hooks.on("deleteActor", () => { Stage.refresh(); Manager.instance?.render(); });

/* bouton dans les contrôles de scène (MJ) */
Hooks.on("getSceneControlButtons", (controls) => {
  if (!game.user?.isGM) return;
  const tool = { name: "pnjManhwa", title: "PNJ Manhwa — Groupes & Scène", icon: "fa-solid fa-people-group", button: true, visible: true, order: 99, onChange: () => Manager.open(), onClick: () => Manager.open() };
  if (Array.isArray(controls)) { const t = controls.find(c => c.name === "token"); t?.tools?.push(tool); }
  else { const t = controls.tokens || controls.token; if (t?.tools) t.tools.pnjManhwa = tool; }
});
