/* PNJ Manhwa — fenêtre de gestion (MJ) */
import { MOD, THEMES, POSITIONS, FRAMES, getData, updateData, getScene, setScene, npcView, ensureNpc, sortMembers, uid, esc } from "./main.js";

const AppV2 = foundry.applications.api.ApplicationV2;
const DialogV2 = foundry.applications.api.DialogV2;
const elOf = d => d?.element instanceof HTMLElement ? d.element : (d instanceof HTMLElement ? d : (d?.[0] ?? document));
const FP = () => foundry.applications?.apps?.FilePicker?.implementation ?? FilePicker;
const sel = (name, opts, cur, cls = "") => `<select name="${name}" class="${cls}">${Object.entries(opts).map(([k, v]) => `<option value="${esc(k)}"${k === cur ? " selected" : ""}>${esc(v)}</option>`).join("")}</select>`;

export class Manager extends AppV2 {
  static instance = null;
  static DEFAULT_OPTIONS = { id: "pm-manager", classes: ["pm-manager"], window: { title: "PNJ Manhwa — Groupes & Scène", icon: "fa-solid fa-people-group", resizable: true }, position: { width: 1120, height: 740 } };
  static open() { if (!game.user.isGM) return ui.notifications.warn("Réservé au MJ."); Manager.instance ??= new Manager(); Manager.instance.render(true); }
  constructor(...a) { super(...a); this.groupId = null; this.sort = "manual"; this.filterTag = ""; this.search = ""; }
  _onClose() { Manager.instance = null; }

  /* ───────── rendu ───────── */
  async _renderHTML() {
    const data = getData(), scene = getScene();
    if (!data.groups.find(g => g.id === this.groupId)) this.groupId = data.groups[0]?.id || null;
    const g = data.groups.find(x => x.id === this.groupId);
    const groups = data.groups.map(x => `<li class="pm-g${x.id === this.groupId ? " sel" : ""}" data-id="${x.id}" draggable="true"><span class="n">${esc(x.name)}</span><span class="c">${x.members.length}</span>
      <span class="acts"><a data-act="g-rename" title="Renommer"><i class="fa-solid fa-pen"></i></a><a data-act="g-up" title="Monter"><i class="fa-solid fa-chevron-up"></i></a><a data-act="g-down" title="Descendre"><i class="fa-solid fa-chevron-down"></i></a><a data-act="g-del" title="Supprimer" class="danger"><i class="fa-solid fa-xmark"></i></a></span></li>`).join("");
    const tags = data.tags.map(t => `<li class="pm-t" data-id="${t.id}"><i class="dot" style="--tc:${esc(t.color)}"></i><span class="n">${esc(t.name)}</span><span class="c">${Object.values(data.npcs).filter(n => (n.tags || []).includes(t.id)).length}</span>
      <span class="acts"><a data-act="t-edit" title="Modifier"><i class="fa-solid fa-pen"></i></a><a data-act="t-del" title="Supprimer" class="danger"><i class="fa-solid fa-xmark"></i></a></span></li>`).join("");

    let main;
    if (!g) main = `<div class="pm-empty"><i class="fa-solid fa-people-group"></i><p>Aucun groupe. Créez-en un à gauche, puis glissez des acteurs depuis le répertoire ou utilisez « Ajouter des PNJ ».</p></div>`;
    else {
      let views = sortMembers(g.members, this.sort, data);
      if (this.filterTag) views = views.filter(v => v.tagIds.includes(this.filterTag));
      if (this.search) { const q = this.search.toLowerCase(); views = views.filter(v => v.realName.toLowerCase().includes(q) || (v.actor?.name || "").toLowerCase().includes(q)); }
      const cards = views.map(v => {
        const tagsHtml = v.tags.map(t => `<span class="pm-tag" style="--tc:${esc(t.color)}">${esc(t.name)}</span>`).join("") || `<span class="pm-tag none">sans étiquette</span>`;
        const sub = v.exists ? (v.actor.name !== v.realName ? `<span class="sub">acteur : ${esc(v.actor.name)}</span>` : "") : `<span class="sub danger">acteur introuvable</span>`;
        return `<div class="pm-m${v.shown ? " on" : ""}${v.speaker ? " spk" : ""}${v.exists ? "" : " missing"}" data-id="${v.id}" draggable="${this.sort === "manual" && !this.filterTag && !this.search}">
          <div class="pm-thumb${v.hidePortrait ? " masked" : ""}" style="background-image:url('${esc(v.img).replace(/'/g, "%27")}')"><i class="fa-solid fa-mask"></i></div>
          <div class="pm-info"><div class="nm">${esc(v.realName)} ${v.revealed ? `<i class="fa-solid fa-eye rev" title="Nom révélé aux joueurs"></i>` : `<i class="fa-solid fa-eye-slash unrev" title="Nom caché : les joueurs voient ???"></i>`}</div>${sub}<div class="tags">${tagsHtml}</div></div>
          <div class="pm-btns">
            <a data-act="m-shown" class="${v.shown ? "on" : ""}" title="${v.shown ? "Retirer de l'écran" : "Afficher à l'écran"}"><i class="fa-solid fa-tv"></i></a>
            <a data-act="m-speaker" class="${v.speaker ? "on spk" : ""}" title="${v.speaker ? "Ne parle plus" : "Orateur (mis en avant)"}"><i class="fa-solid fa-comment"></i></a>
            <a data-act="m-reveal" class="${v.revealed ? "on" : ""}" title="${v.revealed ? "Cacher le nom (??? pour les joueurs)" : "Révéler le nom aux joueurs (définitif)"}"><i class="fa-solid ${v.revealed ? "fa-eye" : "fa-eye-slash"}"></i></a>
            <a data-act="m-mask" class="${v.hidePortrait ? "on" : ""}" title="${v.hidePortrait ? "Montrer le portrait" : "Masquer le portrait (silhouette)"}"><i class="fa-solid fa-mask"></i></a>
            <a data-act="m-tags" title="Étiquettes"><i class="fa-solid fa-tags"></i></a>
            <a data-act="m-edit" title="Alias et image de remplacement"><i class="fa-solid fa-pen"></i></a>
            <a data-act="m-remove" class="danger" title="Retirer du groupe"><i class="fa-solid fa-xmark"></i></a>
          </div></div>`;
      }).join("");
      main = `<div class="pm-ghead"><h2>${esc(g.name)} <small>${g.members.length} PNJ</small></h2>
        <div class="tools">
          <button data-act="m-add"><i class="fa-solid fa-user-plus"></i> Ajouter des PNJ</button>
          <button data-act="m-all-on" title="Afficher tout le groupe à l'écran (dans l'ordre courant)"><i class="fa-solid fa-tv"></i> Tout à l'écran</button>
          <button data-act="m-all-off" title="Vider l'écran"><i class="fa-solid fa-eye-slash"></i> Vider l'écran</button>
          <button data-act="m-no-speaker" title="Plus aucun orateur"><i class="fa-solid fa-comment-slash"></i> Aucun orateur</button>
        </div>
        <div class="tools">
          <label>Tri ${sel("sort", { manual: "Manuel (glisser)", name: "Nom", tag: "Étiquette" }, this.sort)}</label>
          <label>Filtre ${sel("filterTag", { "": "Toutes les étiquettes", ...Object.fromEntries(data.tags.map(t => [t.id, t.name])) }, this.filterTag)}</label>
          <label class="grow"><i class="fa-solid fa-magnifying-glass"></i><input type="text" name="search" placeholder="Rechercher…" value="${esc(this.search)}"></label>
        </div></div>
        <div class="pm-members" data-drop="1">${cards || `<div class="pm-empty small"><p>Groupe vide. Glissez des acteurs ici depuis le répertoire, ou « Ajouter des PNJ ».</p></div>`}</div>`;
    }

    const shownCount = scene.shown.length;
    const sceneBar = `<div class="pm-scene${scene.active ? " live" : ""}">
      <button data-act="s-toggle" class="big ${scene.active ? "on" : ""}"><i class="fa-solid ${scene.active ? "fa-eye" : "fa-eye-slash"}"></i> ${scene.active ? "SCÈNE VISIBLE" : "SCÈNE MASQUÉE"}</button>
      <span class="cnt">${shownCount} à l'écran · ${scene.speakers.length} orateur(s)</span>
      <label>Thème ${sel("theme", THEMES, scene.theme)}</label>
      <label>Position ${sel("position", POSITIONS, scene.position)}</label>
      <label>Cadre ${sel("frame", FRAMES, scene.frame)}</label>
      <label>Taille <input type="range" name="size" min="60" max="320" step="5" value="${scene.size}"><output>${scene.size}px</output></label>
      <label class="chk"><input type="checkbox" name="bg"${scene.bg ? " checked" : ""}> Fond</label>
      <label class="chk"><input type="checkbox" name="showTags"${scene.showTags ? " checked" : ""}> Étiquettes visibles des joueurs</label>
      <label class="grow">Titre <input type="text" name="title" placeholder="Titre de la scène (facultatif)" value="${esc(scene.title)}"></label>
    </div>`;

    return `<div class="pm-wrap">
      ${sceneBar}
      <div class="pm-body">
        <aside class="pm-side">
          <h3><i class="fa-solid fa-layer-group"></i> Groupes <a data-act="g-add" title="Nouveau groupe"><i class="fa-solid fa-plus"></i></a></h3>
          <ul class="pm-groups">${groups || `<li class="hint">Aucun groupe</li>`}</ul>
          <h3><i class="fa-solid fa-tags"></i> Étiquettes <a data-act="t-add" title="Nouvelle étiquette"><i class="fa-solid fa-plus"></i></a></h3>
          <ul class="pm-tagsl">${tags || `<li class="hint">Aucune étiquette — créez « Groupe 1 », « Classe S »…</li>`}</ul>
        </aside>
        <section class="pm-main">${main}</section>
      </div></div>`;
  }
  _replaceHTML(result, content) { content.innerHTML = result; this._activate(content.firstElementChild); if (this._focusSearch) { const s = content.querySelector('[name="search"]'); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } this._focusSearch = false; } }

  /* ───────── interactions ───────── */
  _activate(root) {
    root.addEventListener("click", ev => { const a = ev.target.closest("[data-act]"); if (a) { ev.preventDefault(); this._act(a.dataset.act, a, ev); } });
    root.querySelectorAll(".pm-groups .pm-g").forEach(li => li.addEventListener("click", ev => { if (ev.target.closest("[data-act]")) return; this.groupId = li.dataset.id; this.render(); }));
    /* réglages de scène */
    const on = (n, fn) => root.querySelector(`[name="${n}"]`)?.addEventListener("change", fn);
    on("theme", e => setScene({ theme: e.target.value })); on("position", e => setScene({ position: e.target.value })); on("frame", e => setScene({ frame: e.target.value }));
    on("bg", e => setScene({ bg: e.target.checked })); on("showTags", e => setScene({ showTags: e.target.checked })); on("title", e => setScene({ title: e.target.value.trim() }));
    const size = root.querySelector('[name="size"]'); if (size) { size.addEventListener("input", () => size.nextElementSibling.textContent = size.value + "px"); size.addEventListener("change", () => setScene({ size: Number(size.value) })); }
    on("sort", e => { this.sort = e.target.value; this.render(); }); on("filterTag", e => { this.filterTag = e.target.value; this.render(); });
    const s = root.querySelector('[name="search"]'); if (s) { let t; s.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { this.search = s.value; this._focusSearch = true; this.render(); }, 250); }); }
    /* dépôt d'acteurs */
    const drop = root.querySelector("[data-drop]") || root.querySelector(".pm-main");
    if (drop) {
      drop.addEventListener("dragover", ev => { if (ev.dataTransfer.types.includes("text/plain")) { ev.preventDefault(); drop.classList.add("over"); } });
      drop.addEventListener("dragleave", () => drop.classList.remove("over"));
      drop.addEventListener("drop", async ev => { drop.classList.remove("over"); let d; try { d = JSON.parse(ev.dataTransfer.getData("text/plain")); } catch (e) { return; }
        if (d?.pmMember) return; ev.preventDefault();
        if (d?.type !== "Actor") return; const doc = await fromUuid(d.uuid); if (!doc) return; await this._addActors([doc.id]); });
    }
    /* réordonnancement manuel des membres */
    root.querySelectorAll('.pm-m[draggable="true"]').forEach(card => {
      card.addEventListener("dragstart", ev => { ev.dataTransfer.setData("text/plain", JSON.stringify({ pmMember: card.dataset.id })); card.classList.add("drag"); });
      card.addEventListener("dragend", () => card.classList.remove("drag"));
      card.addEventListener("dragover", ev => { ev.preventDefault(); card.classList.add("target"); });
      card.addEventListener("dragleave", () => card.classList.remove("target"));
      card.addEventListener("drop", async ev => { card.classList.remove("target"); let d; try { d = JSON.parse(ev.dataTransfer.getData("text/plain")); } catch (e) { return; } if (!d?.pmMember || d.pmMember === card.dataset.id) return; ev.preventDefault(); ev.stopPropagation();
        await updateData(data => { const g = data.groups.find(x => x.id === this.groupId); if (!g) return false; const from = g.members.indexOf(d.pmMember), to = g.members.indexOf(card.dataset.id); if (from < 0 || to < 0) return false; g.members.splice(from, 1); g.members.splice(to, 0, d.pmMember); }); });
    });
    /* réordonnancement des groupes par glisser */
    root.querySelectorAll(".pm-g").forEach(li => {
      li.addEventListener("dragstart", ev => ev.dataTransfer.setData("text/plain", JSON.stringify({ pmGroup: li.dataset.id })));
      li.addEventListener("dragover", ev => ev.preventDefault());
      li.addEventListener("drop", async ev => { let d; try { d = JSON.parse(ev.dataTransfer.getData("text/plain")); } catch (e) { return; } if (!d?.pmGroup || d.pmGroup === li.dataset.id) return; ev.preventDefault();
        await updateData(data => { const from = data.groups.findIndex(x => x.id === d.pmGroup), to = data.groups.findIndex(x => x.id === li.dataset.id); const [g] = data.groups.splice(from, 1); data.groups.splice(to, 0, g); }); });
    });
  }

  async _act(act, a, ev) {
    const gid = a.closest(".pm-g")?.dataset.id, tid = a.closest(".pm-t")?.dataset.id, mid = a.closest(".pm-m")?.dataset.id;
    switch (act) {
      /* groupes */
      case "g-add": { const name = await askText("Nouveau groupe", "Nom du groupe", ""); if (!name) return; const id = uid(); await updateData(d => { d.groups.push({ id, name, members: [] }); }); this.groupId = id; break; }
      case "g-rename": { const g = getData().groups.find(x => x.id === gid); const name = await askText("Renommer le groupe", "Nom du groupe", g.name); if (!name) return; await updateData(d => { d.groups.find(x => x.id === gid).name = name; }); break; }
      case "g-del": { const g = getData().groups.find(x => x.id === gid); if (!await DialogV2.confirm({ window: { title: "Supprimer le groupe" }, content: `<p>Supprimer <b>${esc(g.name)}</b> ? Les PNJ restent dans le monde ; seuls le groupe et son ordre disparaissent.</p>` })) return; await updateData(d => { d.groups = d.groups.filter(x => x.id !== gid); }); break; }
      case "g-up": case "g-down": await updateData(d => { const i = d.groups.findIndex(x => x.id === gid), j = act === "g-up" ? i - 1 : i + 1; if (j < 0 || j >= d.groups.length) return false; [d.groups[i], d.groups[j]] = [d.groups[j], d.groups[i]]; }); break;
      /* étiquettes */
      case "t-add": { const r = await askTag("Nouvelle étiquette", { name: "", color: "#38e0ff" }); if (!r) return; await updateData(d => { d.tags.push({ id: uid(), ...r }); }); break; }
      case "t-edit": { const t = getData().tags.find(x => x.id === tid); const r = await askTag("Modifier l'étiquette", t); if (!r) return; await updateData(d => { Object.assign(d.tags.find(x => x.id === tid), r); }); break; }
      case "t-del": { const t = getData().tags.find(x => x.id === tid); if (!await DialogV2.confirm({ window: { title: "Supprimer l'étiquette" }, content: `<p>Supprimer <b>${esc(t.name)}</b> ? Elle sera retirée de tous les PNJ.</p>` })) return; await updateData(d => { d.tags = d.tags.filter(x => x.id !== tid); for (const n of Object.values(d.npcs)) n.tags = (n.tags || []).filter(x => x !== tid); }); break; }
      /* membres */
      case "m-add": await this._pickActors(); break;
      case "m-remove": await updateData(d => { const g = d.groups.find(x => x.id === this.groupId); g.members = g.members.filter(x => x !== mid); }); { const s = getScene(); if (s.shown.includes(mid) && !getData().groups.some(g => g.members.includes(mid))) await setScene({ shown: s.shown.filter(x => x !== mid), speakers: s.speakers.filter(x => x !== mid) }); } break;
      case "m-shown": { const s = getScene(); const shown = s.shown.includes(mid) ? s.shown.filter(x => x !== mid) : [...s.shown, mid]; await setScene({ shown, speakers: s.speakers.filter(x => shown.includes(x)) }); break; }
      case "m-speaker": { const s = getScene(); const speakers = s.speakers.includes(mid) ? s.speakers.filter(x => x !== mid) : [...s.speakers, mid]; const shown = s.shown.includes(mid) ? s.shown : [...s.shown, mid]; await setScene({ speakers, shown }); break; }
      case "m-reveal": await updateData(d => { const n = ensureNpc(d, mid); n.revealed = !n.revealed; }); break;
      case "m-mask": await updateData(d => { const n = ensureNpc(d, mid); n.hidePortrait = !n.hidePortrait; }); break;
      case "m-tags": await this._editTags(mid); break;
      case "m-edit": await this._editMember(mid); break;
      case "m-all-on": { const g = getData().groups.find(x => x.id === this.groupId); const shown = sortMembers(g.members, this.sort, getData()).map(v => v.id); await setScene({ shown, speakers: getScene().speakers.filter(x => shown.includes(x)), active: true }); break; }
      case "m-all-off": await setScene({ shown: [], speakers: [] }); break;
      case "m-no-speaker": await setScene({ speakers: [] }); break;
      /* scène */
      case "s-toggle": await setScene({ active: !getScene().active }); break;
    }
    this.render();
  }

  async _addActors(ids) {
    await updateData(d => { const g = d.groups.find(x => x.id === this.groupId); if (!g) { ui.notifications.warn("Sélectionnez d'abord un groupe."); return false; } for (const id of ids) { if (!g.members.includes(id)) g.members.push(id); ensureNpc(d, id); } });
  }
  async _pickActors() {
    if (!this.groupId) return ui.notifications.warn("Créez ou sélectionnez un groupe d'abord.");
    const g = getData().groups.find(x => x.id === this.groupId);
    const actors = game.actors.contents.slice().sort((a, b) => a.name.localeCompare(b.name, "fr"));
    const folders = f => { const p = []; let x = f; while (x) { p.unshift(x.name); x = x.folder; } return p.join(" / "); };
    const rows = actors.map(a => `<label class="pm-pick${g.members.includes(a.id) ? " in" : ""}" data-n="${esc((a.name + " " + folders(a.folder) + " " + a.type).toLowerCase())}"><input type="checkbox" name="a" value="${a.id}"${g.members.includes(a.id) ? " checked disabled" : ""}><img src="${esc(a.img)}"><span class="n">${esc(a.name)}</span><span class="f">${esc(folders(a.folder))}</span><span class="t">${esc(a.type)}</span></label>`).join("");
    const content = `<div class="pm-picker"><input type="text" class="q" placeholder="Filtrer par nom, dossier, type…" autofocus><div class="list">${rows}</div></div>`;
    const ids = await DialogV2.prompt({ window: { title: `Ajouter des PNJ à « ${g.name} »`, icon: "fa-solid fa-user-plus" }, classes: ["pm-dialog"], position: { width: 560 }, content,
      ok: { label: "Ajouter la sélection", icon: "fa-solid fa-check", callback: (ev, btn) => [...btn.form.querySelectorAll('input[name="a"]:checked:not(:disabled)')].map(i => i.value) },
      render: (ev, dlg) => { const el = elOf(dlg); const q = el.querySelector(".q"); q.addEventListener("input", () => { const v = q.value.toLowerCase(); el.querySelectorAll(".pm-pick").forEach(l => l.style.display = l.dataset.n.includes(v) ? "" : "none"); }); } });
    if (ids?.length) await this._addActors(ids);
  }
  async _editTags(mid) {
    const data = getData(); const v = npcView(mid, data);
    if (!data.tags.length) return ui.notifications.info("Créez d'abord des étiquettes (colonne de gauche).");
    const content = `<div class="pm-tagpick">${data.tags.map(t => `<label><input type="checkbox" name="t" value="${t.id}"${v.tagIds.includes(t.id) ? " checked" : ""}><span class="pm-tag" style="--tc:${esc(t.color)}">${esc(t.name)}</span></label>`).join("")}</div>`;
    const r = await DialogV2.prompt({ window: { title: `Étiquettes — ${v.realName}`, icon: "fa-solid fa-tags" }, classes: ["pm-dialog"], content, ok: { label: "Enregistrer", callback: (ev, btn) => [...btn.form.querySelectorAll('input[name="t"]:checked')].map(i => i.value) } });
    if (!r) return; await updateData(d => { ensureNpc(d, mid).tags = r; });
  }
  async _editMember(mid) {
    const data = getData(); const n = ensureNpc(data, mid); const a = game.actors.get(mid);
    const content = `<div class="pm-form">
      <label>Alias affiché (vide = nom de l'acteur « ${esc(a?.name || "")} »)<input type="text" name="alias" value="${esc(n.alias)}" placeholder="ex. L'homme au chapeau"></label>
      <label>Image de remplacement (vide = portrait de l'acteur)<span class="row"><input type="text" name="img" value="${esc(n.img)}" placeholder="chemin d'une image"><button type="button" class="browse" title="Parcourir"><i class="fa-solid fa-folder-open"></i></button></span></label>
      <div class="prev"><img src="${esc(n.img || a?.img || "")}"></div></div>`;
    const r = await DialogV2.prompt({ window: { title: `Alias et image — ${n.alias || a?.name || ""}`, icon: "fa-solid fa-pen" }, classes: ["pm-dialog"], content,
      ok: { label: "Enregistrer", callback: (ev, btn) => ({ alias: btn.form.elements.alias.value.trim(), img: btn.form.elements.img.value.trim() }) },
      render: (ev, dlg) => { const el = elOf(dlg); const inp = el.querySelector('[name="img"]'); const prev = el.querySelector(".prev img"); inp.addEventListener("change", () => prev.src = inp.value || a?.img || ""); el.querySelector(".browse").addEventListener("click", () => new (FP())({ type: "image", current: inp.value, callback: p => { inp.value = p; prev.src = p; } }).render(true)); } });
    if (!r) return; await updateData(d => { Object.assign(ensureNpc(d, mid), r); });
  }
}

/* petites boîtes de saisie */
async function askText(title, label, value) {
  const r = await DialogV2.prompt({ window: { title }, classes: ["pm-dialog"], content: `<div class="pm-form"><label>${esc(label)}<input type="text" name="v" value="${esc(value)}" autofocus></label></div>`, ok: { label: "Valider", callback: (ev, btn) => btn.form.elements.v.value.trim() } });
  return r || null;
}
async function askTag(title, t) {
  const swatches = ["#38e0ff", "#b980ff", "#ff4d5e", "#ffd070", "#5aff9a", "#ff8af0", "#ff9b3d", "#8fd4ff", "#ffffff"].map(c => `<button type="button" class="sw" data-c="${c}" style="--tc:${c}"></button>`).join("");
  const r = await DialogV2.prompt({ window: { title, icon: "fa-solid fa-tag" }, classes: ["pm-dialog"], content: `<div class="pm-form"><label>Nom<input type="text" name="name" value="${esc(t.name)}" placeholder="ex. Groupe 1, Classe S, Marchand" autofocus></label><label>Couleur<span class="row"><input type="color" name="color" value="${esc(t.color)}">${swatches}</span></label></div>`,
    ok: { label: "Valider", callback: (ev, btn) => ({ name: btn.form.elements.name.value.trim(), color: btn.form.elements.color.value }) },
    render: (ev, dlg) => { const el = elOf(dlg); el.querySelectorAll(".sw").forEach(b => b.addEventListener("click", () => el.querySelector('[name="color"]').value = b.dataset.c)); } });
  return r?.name ? r : null;
}
