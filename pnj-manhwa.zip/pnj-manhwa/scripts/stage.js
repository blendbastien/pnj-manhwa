/* PNJ Manhwa — la scène affichée à l'écran (joueurs et MJ) */
import { MOD, getData, getScene, setScene, npcView, esc } from "./main.js";

let lastSpeakers = null;

export class Stage {
  static el() {
    let el = document.getElementById("pm-stage");
    if (!el) { el = document.createElement("div"); el.id = "pm-stage"; document.body.appendChild(el); el.addEventListener("click", Stage.onClick); }
    return el;
  }
  static refresh() {
    const el = Stage.el(); const scene = getScene(); const data = getData();
    const views = scene.active ? scene.shown.map(id => npcView(id, data, scene)).filter(v => v.exists) : [];
    if (!views.length) { el.classList.remove("on"); el.innerHTML = ""; lastSpeakers = null; return; }
    const scale = game.settings.get(MOD, "playerScale") || 1;
    el.className = `on pos-${scene.position} frame-${scene.frame} theme-${scene.theme}${scene.bg ? " with-bg" : ""}${scene.speakers.length ? " has-speaker" : ""}${game.user.isGM ? " gm" : ""}`;
    el.style.setProperty("--pm-size", Math.round(scene.size * scale) + "px");
    const cards = views.map(v => {
      const cls = ["pm-card", v.speaker ? "speaker" : "", v.hidePortrait ? "masked" : "", v.revealed ? "" : "unknown"].filter(Boolean).join(" ");
      const tags = scene.showTags && v.tags.length ? `<div class="pm-tags">${v.tags.map(t => `<span class="pm-tag" style="--tc:${esc(t.color)}">${esc(t.name)}</span>`).join("")}</div>` : "";
      return `<div class="${cls}" data-id="${v.id}" title="${game.user.isGM ? esc(v.realName) : ""}">
        <div class="pm-frame"><div class="pm-img" style="background-image:url('${esc(v.img).replace(/'/g, "%27")}')"></div><div class="pm-mask"><i class="fa-solid fa-question"></i></div><i class="pm-chev fa-solid fa-caret-down"></i></div>
        <div class="pm-name">${esc(v.name)}</div>${tags}</div>`;
    }).join("");
    el.innerHTML = `${scene.title ? `<div class="pm-title">${esc(scene.title)}</div>` : ""}<div class="pm-bar">${cards}</div>`;
    /* son doux à la prise de parole */
    const sig = scene.speakers.join(",");
    if (lastSpeakers !== null && sig !== lastSpeakers && scene.speakers.length) Stage.ding();
    lastSpeakers = sig;
  }
  static ding() {
    const src = game.settings.get(MOD, "sound"); if (!src) return;
    const volume = game.settings.get(MOD, "soundVolume") ?? 0.25;
    try { (foundry.audio?.AudioHelper ?? AudioHelper).play({ src, volume, autoplay: true, loop: false }, false); } catch (e) { console.warn(MOD, e); }
  }
  static async onClick(ev) {
    if (!game.user.isGM || !game.settings.get(MOD, "gmClickSpeaker")) return;
    const card = ev.target.closest(".pm-card"); if (!card) return;
    const id = card.dataset.id; const s = getScene();
    const speakers = s.speakers.includes(id) ? s.speakers.filter(x => x !== id) : [...s.speakers, id];
    await setScene({ speakers });
  }
}
